﻿(function () {
    'use strict';

    angular.module('MovieSearcher', ['ui.bootstrap', 'ui.select']);
})();