﻿(function () {
    'use strict';

    angular
        .module('MovieSearcher')
        .controller('MovieController', MovieController);

    MovieController.$inject = ['$http'];

    function MovieController($http) {
        var vm = this;
        vm.IsQuerying = false;

        vm.title = null;
        vm.titles = [];

        vm.search = search;
        vm.clear = clearSearchResult;

        function clearSearchResult() {
            vm.title = null;
            vm.isShowTitleDetails = false;
        }

        function search(searchText) {
            //  Used to toggle loading icon
            vm.IsQuerying = true;
            //  Clear current results if we got nothing
            if (searchText == "")
                vm.titles = [];

            return $http.get('/api/movies/search/' + searchText)
                .then(
                function (response) {
                    vm.titles = response.data;
                    vm.IsQuerying = false;
                }, 
                function (error) {
                    vm.titles = [];
                    vm.IsQuerying = false;
                    alert("Service is not available");
                });
        }
    }
})();
