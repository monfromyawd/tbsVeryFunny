﻿using MovieSearcher.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MovieSearcher.Controllers.Api
{
    [RoutePrefix("api/movies")]
    public class MoviesController : ApiController
    {
        [Route("search/{searchText?}")]
        public IEnumerable<Title> Get(string searchText = "")
        {
            return MovieSearcher.Models.Movie.SearchTitles(searchText);
        }
    }
}