﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MovieSearcher.Models
{
    public class Movie
    {
        /// <summary>
        /// Perform search on Titles on Name, Actors and Genre fields using the provided searchText
        /// </summary>
        /// <param name="searchText"></param>
        /// <returns></returns>
        public static IEnumerable<Title> SearchTitles(string searchText)
        {
            using (var dbContext = new TitlesEntities())
            {
                return dbContext.Titles.Where(titleSearch => 
                            (titleSearch.Name.ToLower().Contains(searchText.Trim().ToLower()) ||
                             titleSearch.Actors.ToLower().Contains(searchText.Trim().ToLower()) ||
                             titleSearch.Genre.ToLower().Contains(searchText.Trim().ToLower()) 
                            ) 
                                && searchText.Trim() != string.Empty).ToList().OrderBy(srt => srt.Name);
            }
        }
    }

    
}